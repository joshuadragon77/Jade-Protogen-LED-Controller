import * as ChildProcess from "child_process";
import Express from "express";
import { rmSync } from "fs";


const expressServer = Express();

const driverProcess = ChildProcess.spawn("sudo", ["./jadeled"]);

type Modes = "Normal" | "Blink" | "Angry" | "Happy" | "Pride";

let currentModes: Modes = "Normal";

let recordingProcess: ChildProcess.ChildProcess | null;
let playbackProcess: ChildProcess.ChildProcess | null;

process.on("SIGINT", ()=>{
    driverProcess.kill();
    recordingProcess?.kill();
    playbackProcess?.kill();
    process.exit(0);
});
process.on("exit", ()=>{
    driverProcess.kill();
    recordingProcess?.kill();
    playbackProcess?.kill();
});
process.on("beforeExit", ()=>{
    driverProcess.kill();
    recordingProcess?.kill();
    playbackProcess?.kill();
});

function setMode(newMode: Modes){
    switch(newMode){
        case "Normal":{
            currentModes = "Normal";
            driverProcess.stdin.write("n\n");
            break;
        };
        case "Blink":{
            currentModes = "Blink";
            driverProcess.stdin.write("b\n");
            break;
        };
        case "Angry":{
            currentModes = "Angry";
            driverProcess.stdin.write("a\n");
            break;
        };
        case "Happy":{
            currentModes = "Happy";
            driverProcess.stdin.write("h\n");
            break;
        };
        case "Pride":{
            currentModes = "Pride";
            driverProcess.stdin.write("p\n");
            break;
        };
    }
}


expressServer.use("/SetMode", Express.json());

setInterval(() => {
    setTimeout(() => {
        if (currentModes == "Normal"){
            driverProcess.stdin.write("b\n");
            driverProcess.stdin.write("n\n");
        }
    }, Math.random() * 2000 + 3000);
}, 6000);

expressServer.post("/SetMode", (request, response)=>{
    let body = request.body;

    console.log(body);

    if (body["NewMode"]){
        setMode(body["NewMode"]);
        response.send(currentModes);
    }else{
        response.sendStatus(400);
    }
});

expressServer.get("/SetModeLegacy", (request, response)=>{
    let query = request.query;

    if (query["NewMode"]){
        setMode(query["NewMode"] as Modes);
        response.send(currentModes);
    }else{
        response.sendStatus(400);
    }
});


expressServer.get("/GetCurrentMode", (request, response)=>{
    response.send(currentModes);
});

expressServer.listen(38495, ()=>{
    console.log("Listening...");
});


let recording = false;
let playing = false;

expressServer.get("/Record", (request, response)=>{
    if (playing){
        playbackProcess!.kill();
        playing = false;
    }
    if (recording){
        recordingProcess!.kill();
        recording = false;
    }
    recording = true;
    recordingProcess = ChildProcess.spawn("arecord", ["-fS16_LE", "-r44100", "-d5", "./Recording.mp3"]);
    response.send();
});


expressServer.get("/Playback", (request, response)=>{
    if (playing){
        return;    
    } 
    playing = true;
    if (recording){
        recordingProcess!.kill();
        recording = false;
    }
    playbackProcess = ChildProcess.spawn("aplay", ["./Recording.mp3"]);
    playbackProcess.once("exit", ()=>{
        playing = false; 
        try{
            response.send();
            rmSync("./Recording.mp3");
        }
        catch(er){};
    });
});

let connectingToBluetooth = false;

ChildProcess.exec("bluetoothctl power on");

setInterval(() => {
    if (connectingToBluetooth){
        return;
    }

    connectingToBluetooth = true;

//    ChildProcess.exec("bluetoothctl connect 2C:76:00:D5:D5:FE", ()=>{
//        connectingToBluetooth = false;
//    });
}, 4000);
